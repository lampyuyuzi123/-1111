import React, { useState } from 'react';
import Scene from './components/Scene';
import { TreeState } from './types';

const App: React.FC = () => {
  const [treeState, setTreeState] = useState<TreeState>(TreeState.TREE_SHAPE);

  const toggleState = () => {
    setTreeState((prev) => 
      prev === TreeState.TREE_SHAPE ? TreeState.SCATTERED : TreeState.TREE_SHAPE
    );
  };

  return (
    <div className="w-full h-screen relative bg-black">
      {/* 3D Scene Layer */}
      <div className="absolute inset-0 z-0">
        <Scene treeState={treeState} />
      </div>

      {/* UI Overlay Layer */}
      <div className="absolute inset-0 z-10 pointer-events-none flex flex-col justify-between p-8 md:p-12">
        
        {/* Header */}
        <header className="flex flex-col items-center md:items-start space-y-2 pointer-events-auto">
          <div className="flex items-center space-x-3">
             <div className="w-8 h-[2px] bg-yellow-500 shadow-[0_0_10px_#ffd700]"></div>
             <h2 className="text-yellow-500 tracking-[0.3em] text-xs font-bold uppercase">Arix Signature Series</h2>
             <div className="w-8 h-[2px] bg-yellow-500 shadow-[0_0_10px_#ffd700]"></div>
          </div>
          <h1 className="text-4xl md:text-6xl text-white font-serif tracking-tight drop-shadow-2xl">
            Grand <span className="text-emerald-400 italic">Noël</span>
          </h1>
        </header>

        {/* Controls */}
        <footer className="flex flex-col items-center md:items-end space-y-6 pointer-events-auto">
          <div className="backdrop-blur-md bg-black/30 border border-white/10 p-6 rounded-2xl shadow-2xl max-w-sm">
            <p className="text-gray-300 text-sm mb-4 leading-relaxed font-light">
              Experience the dual nature of celebration. 
              {treeState === TreeState.TREE_SHAPE 
                ? " The order of tradition, gathered in elegance." 
                : " The chaos of joy, scattered in starlight."}
            </p>
            
            <button
              onClick={toggleState}
              className={`
                group relative w-full px-8 py-3 overflow-hidden rounded-sm transition-all duration-500
                ${treeState === TreeState.TREE_SHAPE 
                  ? 'bg-transparent border border-yellow-500/50 hover:bg-yellow-500/10' 
                  : 'bg-emerald-900/80 border border-emerald-500/50 hover:bg-emerald-800'}
              `}
            >
              {/* Button Glow Effect */}
              <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 ease-in-out"></div>
              
              <span className={`
                relative font-bold tracking-widest text-xs uppercase transition-colors duration-300
                ${treeState === TreeState.TREE_SHAPE ? 'text-yellow-400' : 'text-emerald-100'}
              `}>
                {treeState === TreeState.TREE_SHAPE ? 'Scatter Elements' : 'Gather Tree'}
              </span>
            </button>
          </div>
          
          <div className="text-[10px] text-white/30 uppercase tracking-widest">
            Interactive 3D Experience • v1.0
          </div>
        </footer>
      </div>
    </div>
  );
};

export default App;
