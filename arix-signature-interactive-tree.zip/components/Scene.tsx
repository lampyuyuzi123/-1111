import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment, Stars, Sparkles } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing';
import Foliage from './Foliage';
import Ornaments from './Ornaments';
import { TreeState } from '../types';

interface SceneProps {
  treeState: TreeState;
}

const Scene: React.FC<SceneProps> = ({ treeState }) => {
  return (
    <Canvas
      dpr={[1, 2]} // Handle high DPI screens
      gl={{ antialias: false, alpha: false, toneMappingExposure: 1.2 }}
      shadows
    >
      <color attach="background" args={['#010502']} /> {/* Very Dark Green/Black BG */}
      
      {/* Camera */}
      <PerspectiveCamera makeDefault position={[0, 2, 25]} fov={45} />
      <OrbitControls 
        enablePan={false} 
        minPolarAngle={Math.PI / 4} 
        maxPolarAngle={Math.PI / 1.8}
        minDistance={10}
        maxDistance={40}
        autoRotate={treeState === TreeState.TREE_SHAPE}
        autoRotateSpeed={0.5}
      />

      {/* Lighting - Dramatic & Cinematic */}
      <ambientLight intensity={0.2} color="#002200" />
      <spotLight 
        position={[10, 20, 10]} 
        angle={0.3} 
        penumbra={1} 
        intensity={2} 
        color="#ffd700" 
        castShadow 
      />
      <spotLight 
        position={[-10, 5, -10]} 
        angle={0.5} 
        penumbra={1} 
        intensity={1} 
        color="#104020" 
      />
      <pointLight position={[0, -5, 5]} intensity={1} color="#ffaa00" distance={15} />

      {/* 3D Content */}
      <Suspense fallback={null}>
        <group position={[0, -4, 0]}>
            {/* The Green Needles */}
            <Foliage state={treeState} count={12000} />
            
            {/* Gold Baubles */}
            <Ornaments state={treeState} type="bauble" count={150} color="#FFD700" />
            
            {/* Red/Velvet Gift Boxes */}
            <Ornaments state={treeState} type="box" count={40} color="#8a0303" />

             {/* Silver/White fill */}
             <Ornaments state={treeState} type="bauble" count={100} color="#E0E0E0" />
        </group>

        {/* Environment Reflections */}
        <Environment preset="city" />
        
        {/* Background Particles */}
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
        {treeState === TreeState.SCATTERED && (
             <Sparkles count={500} scale={25} size={6} speed={0.4} opacity={0.5} color="#ffd700" />
        )}
      </Suspense>

      {/* Post Processing for the "Arix Signature" Look */}
      <EffectComposer disableNormalPass>
        {/* High intensity bloom for the glowing gold/emerald effect */}
        <Bloom 
          luminanceThreshold={0.8} 
          mipmapBlur 
          intensity={1.5} 
          radius={0.6}
        />
        <Vignette eskil={false} offset={0.1} darkness={0.6} />
      </EffectComposer>
    </Canvas>
  );
};

export default Scene;
