import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TreeState } from '../types';
import { generateFoliageData } from '../utils/geometry';

// -- Shader Code --
// This handles the interpolation (mix) between scatter and tree positions on the GPU for high performance
// It also adds a "breathing" wind effect and gold edge calculation.

const vertexShader = `
  uniform float uTime;
  uniform float uProgress; // 0.0 = Scattered, 1.0 = Tree
  
  attribute vec3 aTreePos;
  attribute vec3 aScatterPos;
  attribute float aRandom;
  
  varying float vRandom;
  varying float vProgress;

  // Simplex noise or simple sine wave for "breathing"
  void main() {
    vRandom = aRandom;
    vProgress = uProgress;

    // 1. Morph Position
    vec3 pos = mix(aScatterPos, aTreePos, uProgress);

    // 2. Add "Life" (Breathing/Floating)
    // Stronger float when scattered, gentle shiver when tree
    float floatFreq = mix(0.5, 2.0, uProgress);
    float floatAmp = mix(0.5, 0.1, uProgress);
    
    pos.y += sin(uTime * floatFreq + aRandom * 10.0) * floatAmp;
    pos.x += cos(uTime * floatFreq * 0.5 + aRandom * 10.0) * floatAmp * 0.5;

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    
    // Size attenuation
    gl_PointSize = (40.0 * (1.0 + aRandom * 0.5)) / -mvPosition.z;
    
    gl_Position = projectionMatrix * mvPosition;
  }
`;

const fragmentShader = `
  uniform float uTime;
  varying float vRandom;
  varying float vProgress;

  void main() {
    // Create a soft circle particle
    vec2 uv = gl_PointCoord.xy - 0.5;
    float r = length(uv);
    if (r > 0.5) discard;

    // -- Colors --
    // Deep Emerald Green
    vec3 emerald = vec3(0.01, 0.2, 0.05);
    // Bright Gold
    vec3 gold = vec3(1.0, 0.85, 0.3);

    // -- Gradient Logic --
    // Center is dark green, Edge is glowing gold
    // Mix based on radius 'r' (0 at center, 0.5 at edge)
    float edgeGlow = smoothstep(0.3, 0.5, r);
    
    // Twinkle effect
    float twinkle = sin(uTime * 3.0 + vRandom * 20.0) * 0.5 + 0.5;
    
    // Final color mix
    // Base is emerald. Edge gets gold.
    vec3 color = mix(emerald, gold, edgeGlow * (0.5 + 0.5 * twinkle));
    
    // Add extra brightness for bloom filter pick-up
    color += gold * edgeGlow * 2.0 * twinkle;

    gl_FragColor = vec4(color, 1.0);
  }
`;

interface FoliageProps {
  state: TreeState;
  count?: number;
}

const Foliage: React.FC<FoliageProps> = ({ state, count = 15000 }) => {
  const meshRef = useRef<THREE.Points>(null);
  
  // Uniforms ref to avoid re-creating object every frame
  const uniforms = useRef({
    uTime: { value: 0 },
    uProgress: { value: 0 },
  });

  // Generate geometry once
  const { treePositions, scatterPositions, randoms } = useMemo(() => generateFoliageData(count), [count]);

  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // Update Time
    uniforms.current.uTime.value += delta;

    // Smoothly interpolate progress
    const target = state === TreeState.TREE_SHAPE ? 1 : 0; // The hook props 'state' is actually the global state passed down
    // Simple lerp for smooth transition
    const current = uniforms.current.uProgress.value;
    const speed = 2.0 * delta; 
    
    if (Math.abs(target - current) > 0.001) {
      if (current < target) uniforms.current.uProgress.value = Math.min(target, current + speed);
      else uniforms.current.uProgress.value = Math.max(target, current - speed);
    }
  });

  return (
    <points ref={meshRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position" // Standard position required for raycasting (even if we override in shader)
          count={treePositions.length / 3}
          array={treePositions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aTreePos"
          count={treePositions.length / 3}
          array={treePositions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aScatterPos"
          count={scatterPositions.length / 3}
          array={scatterPositions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aRandom"
          count={randoms.length}
          array={randoms}
          itemSize={1}
        />
      </bufferGeometry>
      <shaderMaterial
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms.current}
        transparent={true}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};

export default Foliage;
