import React, { useMemo, useRef, useLayoutEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { TreeState } from '../types';
import { getTreePoint, getRandomSpherePoint } from '../utils/geometry';

interface OrnamentsProps {
  state: TreeState;
  type: 'bauble' | 'box';
  count: number;
  color: string;
}

const Ornaments: React.FC<OrnamentsProps> = ({ state, type, count, color }) => {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const tempObj = useMemo(() => new THREE.Object3D(), []);

  // Pre-calculate positions
  const data = useMemo(() => {
    return new Array(count).fill(0).map(() => {
      const scale = type === 'box' ? 0.3 + Math.random() * 0.3 : 0.2 + Math.random() * 0.2;
      return {
        treePos: getTreePoint(11, 4.2, 0.7), // Slightly inside the foliage
        scatterPos: getRandomSpherePoint(18),
        scale: scale,
        rotationSpeed: Math.random() * 0.02,
        phase: Math.random() * Math.PI * 2,
      };
    });
  }, [count, type]);

  // Current progress value (0 to 1) held in a ref for animation loop
  const progress = useRef(0);

  useLayoutEffect(() => {
    // Set initial colors
    if (meshRef.current) {
      const c = new THREE.Color(color);
      // Add slight variation
      for (let i = 0; i < count; i++) {
        // Vary lightness slightly
        const instanceColor = c.clone().offsetHSL(0, 0, (Math.random() - 0.5) * 0.1);
        meshRef.current.setColorAt(i, instanceColor);
      }
      meshRef.current.instanceColor!.needsUpdate = true;
    }
  }, [count, color]);

  useFrame((rootState, delta) => {
    if (!meshRef.current) return;

    // Animate Progress
    const target = state === TreeState.TREE_SHAPE ? 1 : 0;
    const speed = 1.5 * delta;
    if (progress.current < target) progress.current = Math.min(target, progress.current + speed);
    else if (progress.current > target) progress.current = Math.max(target, progress.current - speed);
    
    const p = progress.current;
    // Ease the progress for smoother motion
    // cubic-in-out easing
    const eased = p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;

    const time = rootState.clock.elapsedTime;

    data.forEach((d, i) => {
      // Interpolate Position
      const x = THREE.MathUtils.lerp(d.scatterPos[0], d.treePos[0], eased);
      const y = THREE.MathUtils.lerp(d.scatterPos[1], d.treePos[1], eased);
      const z = THREE.MathUtils.lerp(d.scatterPos[2], d.treePos[2], eased);

      // Add idle floating
      const floatAmp = type === 'box' ? 0.1 : 0.2; // Boxes are heavier/steadier
      const floatY = Math.sin(time + d.phase) * floatAmp * (1 - eased * 0.5); // Float less when in tree form

      tempObj.position.set(x, y + floatY, z);

      // Rotation logic
      // Spin when scattered, stabilize when in tree
      tempObj.rotation.x = d.phase + time * d.rotationSpeed * (1 - eased);
      tempObj.rotation.y = d.phase + time * d.rotationSpeed * (1 - eased);
      
      // Orient correctly for tree (optional, keeping them random looks more organic for this art style)
      // but let's make boxes sit somewhat upright in tree mode
      if (type === 'box') {
          const targetRotX = 0;
          tempObj.rotation.x = THREE.MathUtils.lerp(tempObj.rotation.x, targetRotX, eased);
      }

      tempObj.scale.setScalar(d.scale);
      tempObj.updateMatrix();
      
      meshRef.current!.setMatrixAt(i, tempObj.matrix);
    });

    meshRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh
      ref={meshRef}
      args={[undefined, undefined, count]}
      castShadow
      receiveShadow
    >
      {type === 'box' ? (
        <boxGeometry args={[1, 1, 1]} />
      ) : (
        <sphereGeometry args={[1, 16, 16]} />
      )}
      <meshStandardMaterial
        color={color}
        roughness={type === 'bauble' ? 0.1 : 0.4}
        metalness={type === 'bauble' ? 0.9 : 0.1}
        emissive={color}
        emissiveIntensity={0.2}
      />
    </instancedMesh>
  );
};

export default Ornaments;
