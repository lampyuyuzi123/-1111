import * as THREE from 'three';

// Helper: Random point in sphere
export const getRandomSpherePoint = (radius: number): [number, number, number] => {
  const u = Math.random();
  const v = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const r = Math.cbrt(Math.random()) * radius;
  const sinPhi = Math.sin(phi);
  return [
    r * sinPhi * Math.cos(theta),
    r * sinPhi * Math.sin(theta),
    r * Math.cos(phi)
  ];
};

// Helper: Random point on/in a cone (The Tree)
export const getTreePoint = (height: number, baseRadius: number, verticalBias = 0): [number, number, number] => {
  // y goes from 0 to height roughly
  const y = Math.pow(Math.random(), verticalBias > 0 ? verticalBias : 1) * height; 
  const currentRadius = (1 - y / height) * baseRadius;
  
  // Random angle
  const angle = Math.random() * Math.PI * 2;
  // Random radius within the cone slice (mostly surface but some depth)
  const r = Math.sqrt(Math.random()) * currentRadius;

  const x = Math.cos(angle) * r;
  const z = Math.sin(angle) * r;

  // Center the tree vertically
  return [x, y - height / 2, z];
};

export const generateFoliageData = (count: number) => {
  const treePositions = new Float32Array(count * 3);
  const scatterPositions = new Float32Array(count * 3);
  const randoms = new Float32Array(count); // For twinkling/phase

  for (let i = 0; i < count; i++) {
    const i3 = i * 3;
    const [tx, ty, tz] = getTreePoint(12, 4.5, 0.8); // Tall cone
    const [sx, sy, sz] = getRandomSpherePoint(15); // Large scatter radius

    treePositions[i3] = tx;
    treePositions[i3 + 1] = ty;
    treePositions[i3 + 2] = tz;

    scatterPositions[i3] = sx;
    scatterPositions[i3 + 1] = sy;
    scatterPositions[i3 + 2] = sz;

    randoms[i] = Math.random();
  }

  return { treePositions, scatterPositions, randoms };
};
